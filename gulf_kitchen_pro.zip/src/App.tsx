import React from "react";

const App = () => {
  return (
    <div style={styles.page}>
      <nav style={styles.nav}>
        <h1 style={styles.logo}>GULF KITCHEN PRO</h1>
      </nav>

      <section style={styles.hero}>
        <h2 style={styles.heroTitle}>Commercial Kitchen Equipment</h2>
        <p style={styles.heroSubtitle}>
          Mixers · Ovens · Hoods · Bakery Machinery · Refrigeration Units
        </p>
        <button style={styles.button}>Browse Equipment</button>
      </section>

      <section style={styles.gridSection}>
        <h3 style={styles.sectionTitle}>Featured Equipment</h3>

        <div style={styles.grid}>
          {["Mixer", "Oven", "Hood", "Freezer", "Grill", "Work Table"].map(
            (item) => (
              <div key={item} style={styles.card}>
                <p style={styles.cardText}>{item}</p>
              </div>
            )
          )}
        </div>
      </section>

      <footer style={styles.footer}>
        <p>© 2025 Gulf Kitchen Pro — All rights reserved.</p>
      </footer>
    </div>
  );
};

const styles = {
  page: {
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#fafafa",
    margin: 0,
    padding: 0,
  },
  nav: {
    width: "100%",
    padding: "16px 32px",
    backgroundColor: "#ffffff",
    borderBottom: "1px solid #ddd",
  },
  logo: {
    margin: 0,
    fontSize: "24px",
    fontWeight: "700",
  },
  hero: {
    padding: "80px 32px",
    backgroundColor: "#f2f2f2",
  },
  heroTitle: {
    fontSize: "40px",
    fontWeight: "700",
    marginBottom: "12px",
  },
  heroSubtitle: {
    fontSize: "18px",
    opacity: 0.7,
    marginBottom: "24px",
  },
  button: {
    padding: "12px 20px",
    fontSize: "16px",
    backgroundColor: "black",
    color: "white",
    borderRadius: "6px",
    border: "none",
    cursor: "pointer",
  },
  gridSection: {
    padding: "60px 32px",
  },
  sectionTitle: {
    fontSize: "24px",
    marginBottom: "24px",
  },
  grid: {
    display: "flex",
    flexWrap: "wrap",
    gap: "20px",
  },
  card: {
    width: "160px",
    height: "160px",
    backgroundColor: "#e3e3e3",
    display: "flex",
    justifyContent: "center",
    alignItems": "center",
    borderRadius: "8px",
  },
  cardText: {
    fontSize: "16px",
    fontWeight: "600",
  },
  footer: {
    marginTop: "40px",
    padding: "24px",
    textAlign: "center",
    backgroundColor: "#f2f2f2",
    borderTop: "1px solid #ddd",
  },
};

export default App;
